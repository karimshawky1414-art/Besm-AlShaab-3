/* ══════════════════════════════════════════════════════════════
   settings.js — الإعدادات وسهولة الوصول
   بيتحمّل قبل السكربت الأساسي. مالوش أي اعتماد على S أو CASES.
   ══════════════════════════════════════════════════════════════ */
var Settings = (function(){
  var KEY = 'basm.settings.v1';
  var D = {
    vol: 0.85,        // مستوى المؤثرات 0..1
    gavel: true,      // صوت الشاكوش
    speed: 1,         // سرعة الكتابة: 0 = فوري، 0.5 سريع، 1 عادي، 1.8 بطيء
    font: 1,          // حجم الخط 0.88 .. 1.3
    vibe: true,       // الاهتزاز
    motion: true,     // المؤثرات الحركية
    tts: true         // نطق "رُفعت الجلسة"
  };
  var C = Object.assign({}, D);

  function load(){
    try{
      var raw = localStorage.getItem(KEY);
      if (raw) C = Object.assign({}, D, JSON.parse(raw));
    }catch(e){}
    apply();
  }
  function save(){ try{ localStorage.setItem(KEY, JSON.stringify(C)); }catch(e){} }

  function apply(){
    var b = document.body;
    if (!b) return;
    b.classList.toggle('nomo', !C.motion);
    b.style.setProperty('--fz', C.font);
    b.classList.toggle('fz-on', C.font !== 1);
    applyAudio();
  }
  function applyAudio(){
    try{
      if (typeof A !== 'undefined' && A && A.master && A.ctx)
        A.master.gain.value = A.on ? C.vol : 0;
    }catch(e){}
  }

  /* سرعة الكتابة — بترجع مضاعف التأخير، و0 معناها فوري */
  function speed(){ return C.speed; }
  function instant(){ return C.speed === 0; }

  function vibe(ms){
    if (!C.vibe) return;
    try{ if (navigator.vibrate) navigator.vibrate(ms || 18); }catch(e){}
  }

  /* ── لوحة الإعدادات ── */
  function row(label, hint, control){
    return '<div class="setrow"><div class="sl"><b>' + label + '</b>'
      + (hint ? '<i>' + hint + '</i>' : '') + '</div><div class="sc">' + control + '</div></div>';
  }
  function seg(name, opts, cur){
    return '<div class="seg">' + opts.map(function(o){
      return '<button data-set="' + name + '" data-val="' + o[1] + '"'
        + (String(o[1]) === String(cur) ? ' class="on"' : '') + '>' + o[0] + '</button>';
    }).join('') + '</div>';
  }
  function toggle(name, cur){
    return seg(name, [['شغال', 1], ['مقفول', 0]], cur ? 1 : 0);
  }

  function open(){
    var m = document.getElementById('modal'), c = document.getElementById('mcard');
    if (!m) return;
    c.innerHTML =
      '<div class="crestline">— الإعدادات —</div>'
      + '<h3 style="margin-bottom:12px">ضبط الجلسة</h3>'
      + '<div class="setbox">'
      + row('مستوى المؤثرات', 'دوشة القاعة والورق والشاكوش',
          seg('vol', [['خافت', 0.35], ['متوسط', 0.6], ['عالي', 0.85], ['أقصى', 1]], C.vol))
      + row('صوت الشاكوش', 'لو مقفول، الدقة بتبان من غير صوت', toggle('gavel', C.gavel))
      + row('سرعة الكتابة', 'ظهور كلام الشهود والمستشارين',
          seg('speed', [['فوري', 0], ['سريع', 0.5], ['عادي', 1], ['متمهل', 1.8]], C.speed))
      + row('حجم الخط', 'بيكبّر نص اللعبة كلها',
          seg('font', [['صغير', 0.9], ['عادي', 1], ['كبير', 1.14], ['أكبر', 1.28]], C.font))
      + row('الاهتزاز', 'مع دقة الشاكوش والنطق بالحكم', toggle('vibe', C.vibe))
      + row('المؤثرات الحركية', 'قفلها لو الحركة بتضايقك', toggle('motion', C.motion))
      + row('نطق «رُفعت الجلسة»', 'بيستخدم محرك النطق بتاع الجهاز', toggle('tts', C.tts))
      + '</div>'
      + '<button class="btn" id="setclose"><span class="t">تمام</span></button>';
    m.classList.add('on');

    c.querySelectorAll('[data-set]').forEach(function(b){
      b.onclick = function(){
        var k = b.dataset.set, v = Number(b.dataset.val);
        C[k] = (k === 'gavel' || k === 'vibe' || k === 'motion' || k === 'tts') ? !!v : v;
        save(); apply();
        b.parentElement.querySelectorAll('button').forEach(function(x){ x.classList.remove('on'); });
        b.classList.add('on');
        if (k === 'vol' || k === 'gavel'){
          try{ if (typeof audioInit === 'function') audioInit(); applyAudio();
               if (typeof paperSound === 'function') paperSound(); }catch(e){}
        }
        if (k === 'vibe' && v) vibe(30);
      };
    });
    document.getElementById('setclose').onclick = function(){ m.classList.remove('on'); };
  }

  /* زرار الترس جنب زرار الصوت في لوحة المنصة */
  function mountButton(){
    if (document.getElementById('setbtn')) return;
    var snd = document.getElementById('snd');
    if (!snd) return;
    var b = document.createElement('button');
    b.className = 'sndbtn'; b.id = 'setbtn';
    b.setAttribute('aria-label', 'الإعدادات'); b.title = 'الإعدادات';
    b.textContent = '⚙';
    b.onclick = open;
    snd.parentElement.insertBefore(b, snd);
  }

  return {
    get: function(){ return C; },
    load: load, save: save, apply: apply, applyAudio: applyAudio,
    speed: speed, instant: instant, vibe: vibe,
    open: open, mountButton: mountButton,
    gavelOn: function(){ return C.gavel; },
    ttsOn: function(){ return C.tts; },
    vol: function(){ return C.vol; }
  };
})();
