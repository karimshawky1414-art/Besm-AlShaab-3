/* ══════════════════════════════════════════════════════════════
   art.js — رسومات الأحراز والصور المرفقة
   كل الرسم SVG متولّد جوه اللعبة — مفيش أي صورة فوتوغرافية،
   ومفيش أشخاص حقيقيين ولا بيانات حقيقية. الشكل العام مقصود إنه
   يبان كأنه صورة حرز متصوّرة على ورقة قياس، لأغراض اللعب بس.
   ══════════════════════════════════════════════════════════════ */
var Art = (function(){

  /* إطار «صورة الحرز»: خلفية ورقية + مسطرة قياس + بطاقة تعريف */
  function frame(inner, tag){
    return '<svg viewBox="0 0 200 150" class="artsvg" aria-hidden="true">'
      + '<defs>'
      + '<linearGradient id="apg" x1="0" y1="0" x2="0" y2="1">'
      + '<stop offset="0" stop-color="#D9D3C2"/><stop offset="1" stop-color="#BDB6A2"/></linearGradient>'
      + '</defs>'
      + '<rect width="200" height="150" fill="url(#apg)"/>'
      + '<rect width="200" height="150" fill="none" stroke="#8E8875" stroke-width="1"/>'
      /* مسطرة قياس تحت */
      + '<g stroke="#6E6857" stroke-width="1" opacity=".8">'
      + '<path d="M8 140h184"/>'
      + '<path d="M8 140v-6M28 140v-4M48 140v-6M68 140v-4M88 140v-6M108 140v-4M128 140v-6M148 140v-4M168 140v-6M188 140v-4"/>'
      + '</g>'
      + '<text x="10" y="149" font-size="5" fill="#6E6857" font-family="monospace">cm</text>'
      + '<g transform="translate(0,-6)">' + inner + '</g>'
      /* بطاقة الحرز */
      + '<g transform="translate(140,8)">'
      + '<rect width="52" height="20" fill="#EAE5D6" stroke="#8E8875"/>'
      + '<text x="26" y="9" font-size="6" text-anchor="middle" fill="#4A4436">صورة حرز</text>'
      + '<text x="26" y="16" font-size="5.5" text-anchor="middle" fill="#8B1E2D">' + (tag || 'نموذج داخل اللعبة') + '</text>'
      + '</g>'
      + '</svg>';
  }

  var P = {
    /* سكين مطبخ */
    knife: '<g stroke="#3A3730" stroke-width="1.6" fill="none">'
      + '<path d="M42 88 L128 62 q10 -3 12 4 q2 7 -8 10 L48 100 z" fill="#B9BDC0"/>'
      + '<path d="M42 88 L48 100 L30 106 q-8 3 -10 -4 q-2 -7 6 -9 z" fill="#4A3A26"/>'
      + '<path d="M120 66 L128 68" /></g>',

    /* هاتف محمول */
    phone: '<g><rect x="72" y="26" width="56" height="96" rx="7" fill="#26282B" stroke="#3A3730" stroke-width="1.6"/>'
      + '<rect x="77" y="34" width="46" height="78" rx="2" fill="#8E9AA3"/>'
      + '<rect x="90" y="29" width="20" height="2.4" rx="1.2" fill="#4A4E52"/>'
      + '<g stroke="#5E6B74" stroke-width="1.4"><path d="M83 46h34M83 56h26M83 66h30M83 76h20"/></g>'
      + '<circle cx="100" cy="117" r="3.4" fill="#4A4E52"/></g>',

    /* حقيبة يد */
    bag: '<g><path d="M56 62h88l-7 56H63z" fill="#5A4632" stroke="#3A3730" stroke-width="1.6"/>'
      + '<path d="M78 62c0-16 6-24 22-24s22 8 22 24" fill="none" stroke="#3A3730" stroke-width="3"/>'
      + '<rect x="92" y="78" width="16" height="12" rx="2" fill="#B99A5B" stroke="#3A3730"/></g>',

    /* سيارة */
    car: '<g><path d="M32 96h136l-6-20-18-22H62L40 76z" fill="#7C8A93" stroke="#3A3730" stroke-width="1.6"/>'
      + '<path d="M66 58h64l14 18H54z" fill="#AEB8BE"/>'
      + '<circle cx="64" cy="98" r="12" fill="#26282B"/><circle cx="140" cy="98" r="12" fill="#26282B"/>'
      + '<circle cx="64" cy="98" r="4.5" fill="#8E8875"/><circle cx="140" cy="98" r="4.5" fill="#8E8875"/></g>',

    /* مكان الواقعة — شارع */
    scene: '<g><rect x="10" y="20" width="180" height="72" fill="#9AA0A4"/>'
      + '<path d="M10 92h180v26H10z" fill="#6E6E6C"/>'
      + '<g stroke="#D9D3C2" stroke-width="3" stroke-dasharray="12 10"><path d="M10 106h180"/></g>'
      + '<g fill="#7A6A55" stroke="#4A4436" stroke-width="1.2">'
      + '<rect x="20" y="26" width="34" height="62"/><rect x="62" y="34" width="30" height="54"/>'
      + '<rect x="128" y="30" width="38" height="58"/></g>'
      + '<g fill="#CFC08E" opacity=".85"><rect x="26" y="34" width="9" height="9"/><rect x="40" y="34" width="9" height="9"/>'
      + '<rect x="26" y="50" width="9" height="9"/><rect x="136" y="40" width="10" height="10"/><rect x="151" y="40" width="10" height="10"/></g>'
      + '<path d="M104 88v-32" stroke="#4A4436" stroke-width="2.4"/><circle cx="104" cy="52" r="6" fill="#E8DFA8"/></g>',

    /* كاميرا مراقبة — لقطة */
    cctv: '<g><rect x="16" y="18" width="168" height="96" fill="#3E4448"/>'
      + '<g fill="#5C666B"><rect x="24" y="70" width="152" height="40"/></g>'
      + '<g fill="#8B939A"><rect x="40" y="40" width="26" height="46" rx="2"/><rect x="96" y="34" width="30" height="52" rx="2"/></g>'
      + '<circle cx="53" cy="34" r="8" fill="#A8AFB4"/><circle cx="111" cy="27" r="8" fill="#A8AFB4"/>'
      + '<g stroke="#C7CDD1" stroke-width="1" opacity=".35"><path d="M16 30h168M16 50h168M16 70h168M16 90h168"/></g>'
      + '<text x="24" y="28" font-size="8" fill="#D8E0E4" font-family="monospace">CAM 02</text>'
      + '<text x="128" y="110" font-size="8" fill="#D8E0E4" font-family="monospace">23:41</text></g>',

    /* مستند مضبوط */
    doc: '<g><rect x="60" y="20" width="80" height="104" fill="#EFEADC" stroke="#8E8875" stroke-width="1.4"/>'
      + '<g stroke="#9A9484" stroke-width="1.6"><path d="M70 40h60M70 52h60M70 64h48M70 76h60M70 88h34"/></g>'
      + '<circle cx="120" cy="104" r="13" fill="none" stroke="#8B1E2D" stroke-width="1.6" opacity=".75"/>'
      + '<text x="120" y="107" font-size="6" text-anchor="middle" fill="#8B1E2D" opacity=".8">ختم</text></g>',

    /* نقود */
    cash: '<g><g transform="rotate(-6 100 72)"><rect x="48" y="46" width="104" height="52" rx="3" fill="#9CB08E" stroke="#4A5540" stroke-width="1.4"/>'
      + '<circle cx="100" cy="72" r="15" fill="none" stroke="#4A5540" stroke-width="1.2"/>'
      + '<path d="M58 56h14M128 88h14" stroke="#4A5540" stroke-width="1.2"/></g>'
      + '<rect x="56" y="38" width="96" height="10" rx="2" fill="#C7B27C" stroke="#7A6538" stroke-width="1"/></g>',

    /* أقراص / مادة مضبوطة */
    pills: '<g><path d="M64 52h72l-6 62a10 10 0 0 1-10 9H80a10 10 0 0 1-10-9z" fill="#CFCFC8" stroke="#3A3730" stroke-width="1.5" opacity=".9"/>'
      + '<rect x="60" y="40" width="80" height="14" rx="3" fill="#8E8875" stroke="#3A3730" stroke-width="1.3"/>'
      + '<g fill="#EFEADC" stroke="#8E8875" stroke-width=".9">'
      + '<circle cx="86" cy="82" r="7"/><circle cx="104" cy="76" r="7"/><circle cx="118" cy="90" r="7"/><circle cx="94" cy="98" r="7"/></g></g>',

    /* شنطة سفر / صندوق */
    box: '<g><path d="M46 56h108v62H46z" fill="#9A7F5B" stroke="#3A3730" stroke-width="1.6"/>'
      + '<path d="M46 56l14-14h88l6 14z" fill="#B39468" stroke="#3A3730" stroke-width="1.4"/>'
      + '<path d="M100 42v76" stroke="#3A3730" stroke-width="1.2" opacity=".6"/>'
      + '<rect x="88" y="76" width="24" height="12" fill="#6E6857" stroke="#3A3730"/></g>',

    /* دفتر حسابات */
    ledger: '<g><rect x="52" y="30" width="96" height="90" rx="2" fill="#7A4A3A" stroke="#3A3730" stroke-width="1.5"/>'
      + '<rect x="60" y="36" width="82" height="78" fill="#EFEADC"/>'
      + '<g stroke="#B7AF95" stroke-width="1"><path d="M60 50h82M60 62h82M60 74h82M60 86h82M60 98h82"/></g>'
      + '<g stroke="#5C7FA8" stroke-width="1"><path d="M112 36v78"/></g>'
      + '<g stroke="#3A3730" stroke-width="1.3"><path d="M66 56h32M66 68h26M66 80h34M118 56h18M118 68h14"/></g></g>',

    /* لابتوب */
    laptop: '<g><path d="M62 40h76v52H62z" fill="#3E4448" stroke="#26282B" stroke-width="1.5"/>'
      + '<rect x="67" y="45" width="66" height="42" fill="#7E8A92"/>'
      + '<path d="M46 92h108l10 14H36z" fill="#8E959A" stroke="#26282B" stroke-width="1.4"/>'
      + '<path d="M86 100h28" stroke="#4A4E52" stroke-width="2"/></g>',

    /* مفاتيح */
    keys: '<g stroke="#3A3730" stroke-width="1.5" fill="none">'
      + '<circle cx="72" cy="60" r="14" fill="#B99A5B"/><circle cx="72" cy="60" r="5" fill="#D9D3C2"/>'
      + '<path d="M84 64l44 26" stroke="#B99A5B" stroke-width="7" stroke-linecap="round"/>'
      + '<path d="M118 84l6 10M126 90l6 9" stroke="#B99A5B" stroke-width="5" stroke-linecap="round"/></g>',

    /* ختم / حرز عام */
    seal: '<g><circle cx="100" cy="70" r="34" fill="none" stroke="#8B1E2D" stroke-width="2.4" opacity=".8"/>'
      + '<circle cx="100" cy="70" r="27" fill="none" stroke="#8B1E2D" stroke-width="1" opacity=".6"/>'
      + '<text x="100" y="66" font-size="9" text-anchor="middle" fill="#8B1E2D" opacity=".85">حرز</text>'
      + '<text x="100" y="80" font-size="7" text-anchor="middle" fill="#8B1E2D" opacity=".7">مختوم</text>'
      + '<path d="M60 104h80" stroke="#8E8875" stroke-width="1.4"/></g>',

    /* عبوة دواء */
    med: '<g><rect x="70" y="40" width="60" height="76" rx="4" fill="#DCE6EA" stroke="#3A3730" stroke-width="1.5"/>'
      + '<rect x="70" y="40" width="60" height="18" rx="4" fill="#5C7FA8" opacity=".7"/>'
      + '<g stroke="#7C8A93" stroke-width="1.4"><path d="M80 70h40M80 82h30M80 94h36"/></g>'
      + '<path d="M96 104h8v10h-8z" fill="#8B1E2D" opacity=".6"/></g>',

    /* أداة حادة/عصا */
    stick: '<g><path d="M40 108 L150 44" stroke="#7A5C36" stroke-width="9" stroke-linecap="round"/>'
      + '<path d="M40 108 L60 96" stroke="#4A3A26" stroke-width="11" stroke-linecap="round"/>'
      + '<path d="M132 54l14-8" stroke="#3A3730" stroke-width="2"/></g>'
  };

  /* بيرجع SVG جاهز — لو النوع مش معروف بيرجع ختم الحرز العام */
  function icon(kind, tag){
    var body = P[kind] || P.seal;
    return frame(body, tag);
  }

  function has(kind){ return !!P[kind]; }
  function kinds(){ return Object.keys(P); }

  return { icon:icon, has:has, kinds:kinds, frame:frame };
})();
