/* ══════════════════════════════════════════════════════════════
   profile.js — سجل المسيرة: كل حاجة عملها اللاعب بتتخزن هنا،
   وبيترد عليها في جلسات بعدين. مفيش حدث ثابت ١٠٠٪ بين اللعبات.
   ══════════════════════════════════════════════════════════════ */
var Profile = (function(){

  /* مولّد عشوائي ببذرة — عشان اللعبة تختلف بين Playthrough وTالتاني
     لكن تفضل ثابتة جوه اللعبة الواحدة (مهم للحفظ) */
  function rng(seed){
    var t = seed >>> 0;
    return function(){
      t += 0x6D2B79F5; t = t >>> 0;
      var x = Math.imul(t ^ (t >>> 15), 1 | t);
      x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x;
      return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
    };
  }

  function blank(){
    return {
      seed: (Math.random() * 1e9) | 0,
      decisions: [],       // {i,title,v,ix,probes,qs,defQ,press,match,risk}
      pressTaken: 0,
      pressRefused: 0,
      controversial: 0,    // أحكام انفرد فيها برأيه
      unanimous: 0,
      mediaHeat: 0,        // الضغط الإعلامي المتراكم
      inspection: 0,       // ملاحظات التفتيش القضائي
      independence: 0,     // مؤشر الاستقلال (رفض ضغط + مخالفة الدائرة)
      compliance: 0,       // مؤشر الاستجابة للضغوط
      rel: {},             // علاقة اللاعب بكل مستشار
      echoes: [],          // قرارات قديمة مستنية ترجع {due,i,title,v,kind}
      seen: {}             // إخطارات ظهرت قبل كده عشان ما تتكررش
    };
  }

  var P = blank();

  function init(saved){
    P = Object.assign(blank(), saved || {});
    if (!P.rel) P.rel = {};
    if (!P.echoes) P.echoes = [];
    if (!P.seen) P.seen = {};
    if (!P.decisions) P.decisions = [];
    return P;
  }
  function data(){ return P; }
  function rand(salt){ return rng((P.seed + (salt || 0) * 7919) >>> 0)(); }

  /* ── تسجيل حكم ── */
  function record(entry){
    P.decisions.push(entry);
    if (entry.match === 0){ P.controversial++; P.independence += 1; }
    if (entry.match === 2) P.unanimous++;
    if (entry.press === 'yes'){ P.pressTaken++; P.compliance += 2; P.independence -= 1; }
    if (entry.press === 'no'){ P.pressRefused++; P.independence += 1.5; }
    if (P.independence < 0) P.independence = 0;
    if (P.compliance < 0) P.compliance = 0;

    // القرار ده ممكن يرجع بعد ٣ لـ ٧ جلسات
    var gap = 3 + Math.floor(rand(entry.i + 3) * 5);
    P.echoes.push({ due: entry.i + gap, i: entry.i, title: entry.title, v: entry.v, ix: entry.ix,
                    kind: entry.match === 0 ? 'solo' : (entry.press === 'yes' ? 'press' : 'plain') });
  }

  /* ── سمعة اللاعب كـ«وصف» بيستخدمه المستشارين والإخطارات ── */
  function tier(){
    var t = [];
    if (typeof S === 'undefined') return t;
    if (S.quashed >= 3 && S.quashed > S.upheld) t.push('كثير النقض');
    if (S.upheld >= 4 && S.quashed === 0) t.push('محصّن');
    if (P.compliance >= 4) t.push('لين');
    if (P.independence >= 5) t.push('مستقل');
    if (S.r >= 72) t.push('مشهور');
    if (S.r <= 28) t.push('مطعون فيه');
    if (P.controversial >= 4) t.push('منفرد');
    return t;
  }
  function has(tag){ return tier().indexOf(tag) >= 0; }

  /* ══ إخطارات نابعة من التاريخ نفسه ══
     بترجع array من {kind,bad,k,st,body} تتحط مع إخطارات أول الجلسة */
  function notices(){
    var out = [], n;

    // ملاحظات التفتيش لما النقض يزيد
    if (S.quashed >= 3 && S.quashed > S.upheld && !P.seen['insp' + S.quashed]){
      P.seen['insp' + S.quashed] = 1; P.inspection++;
      out.push({ kind:'hold', bad:true, k:'التفتيش القضائي — مذكرة ملاحظات', st:'قيد النظر',
        body:'إحصائية النقض في دائرتك جاوزت المعدل: <b>' + arNum(S.quashed) + ' أحكام منقوضة</b> '
           + 'مقابل ' + arNum(S.upheld) + ' مؤيدة. المذكرة اتحطت في الملف من غير استدعاء — '
           + 'المرة الجاية بيبقى فيه استدعاء.' });
    }

    // الشهرة بتجيب ضغط إعلامي
    if (S.r >= 70 && P.mediaHeat < 3 && rand(S.i + 11) < 0.5 && !P.seen['media' + S.i]){
      P.seen['media' + S.i] = 1; P.mediaHeat++;
      out.push({ kind:'appeal', k:'مكتب رئيس المحكمة — مذكرة داخلية', st:'للعلم',
        body:'اسمك اتكرر في تغطية صحفية عن أحكام الدائرة. المذكرة بتقول «مع مراعاة عدم الإدلاء '
           + 'بأي تصريحات». الحقيقة اللي مش مكتوبة: الملفات اللي جاية عليك بقى ليها متفرجين.' });
    }

    // اللي بيرضخ بيتطلب منه أكتر
    if (P.compliance >= 4 && !P.seen['comp' + P.pressTaken]){
      P.seen['comp' + P.pressTaken] = 1;
      out.push({ kind:'appeal', k:'ورقة مطوية جوه الملف', st:'بدون توقيع',
        body:'ورقة صغيرة اتلقت جوه حافظة المستندات، مكتوب فيها رقم تليفون وسطر واحد: '
           + '«الأستاذ بيسلّم عليك، وفاكر جميلك». مكتوبش اسم.' });
    }

    // الاستقلال بيتلاحظ برضه
    if (P.independence >= 6 && !P.seen['ind']){
      P.seen['ind'] = 1;
      out.push({ kind:'promo', k:'من زميل في الدائرة المجاورة', st:'خاص',
        body:'«بقوا بيقولوا عنك في المكتب إنك ما بتتكلمش مع حد قبل الجلسة. خد بالك — '
           + 'الوصف ده بيتقال بنبرتين، وإنت مش هتختار النبرة.»' });
    }

    // صدى قرار قديم
    var due = P.echoes.filter(function(e){ return e.due === S.i; });
    P.echoes = P.echoes.filter(function(e){ return e.due !== S.i; });
    due.slice(0, 1).forEach(function(e){
      out.push({ kind:'appeal', k:'وارد المحكمة — متعلق بقضية سابقة', st:'ورد',
        body: echoText(e) });
    });

    return out;
  }

  function echoText(e){
    var t = '<b>' + esc(e.title) + '</b>';
    var pool;
    if (e.kind === 'solo'){
      pool = [
        'وردت مذكرة من نيابة النقض في الطعن على حكمك في قضية ' + t + '. المذكرة بتشير لكلمة '
        + '«انفرد رئيس الدائرة برأيه» وبتعاملها كأنها سبب في ذاتها. هي مش سبب — بس اتكتبت.',
        'محامي في قضية ' + t + ' بعت للمحكمة صورة من حكمك مرفقة بمذكرته في قضية تانية، '
        + 'بيستشهد بيه. أحكامك بقت بتتنقل — بحلوها ومرّها.'
      ];
    } else if (e.kind === 'press'){
      pool = [
        'الحكم اللي أصدرته في ' + t + ' اتعرض في مذكرة بحث داخلية عن «اتساق الأحكام». '
        + 'مفيش اتهام، بس فيه سطر بيقارن حكمك بأحكام تانية في نفس الوصف.',
        'اللي كلّمك في قضية ' + t + ' بعت يشكرك بطريقة غير مباشرة: كارت من مكتب محاماة '
        + 'وصل باسمك للمحكمة. المحضر سلّمهولك وهو ساكت.'
      ];
    } else {
      pool = [
        'وصل خطاب لمكتب المحكمة من أهل ' + t + '. مفيش طلب فيه — شكر بس، وسطر بيقول '
        + '«ربنا يجعله في ميزان حسناتك». المحضر حطه في الملف لأنه مش عارف يحطه فين تاني.',
        'قضية ' + t + ' رجعت اتذكرت في تقرير إحصائي عن أحكام الدائرة. رقمك ظهر في خانة، '
        + 'وخلاص. أغلب اللي بتعمله بيتحول لخانة في الآخر.',
        'اتصلوا من قلم الكتّاب: صورة الحكم في قضية ' + t + ' اتطلبت من جهة ما، '
        + 'وسلّموها. مفيش تفاصيل زيادة.'
      ];
    }
    return pool[Math.floor(rand(e.i + 5) * pool.length)];
  }

  /* ══ ضغط إضافي متولّد من التاريخ (لما القضية نفسها مالهاش pressure) ══ */
  function extraPressure(k){
    if (!k || k.pressure) return null;
    var r = rand(S.i + 23);
    // إعلامي: بيظهر للمشهور
    if (S.r >= 68 && P.mediaHeat >= 1 && r < 0.42){
      return {
        frm: 'قلم الكتّاب — أثناء المداولة',
        ttl: 'صحفيين بره القاعة',
        txt: 'في تلات صحفيين واقفين بره وبيسألوا على منطوق الحكم قبل النطق بيه. '
           + 'رئيس المحكمة بعت يسأل إذا كنت عايز الجلسة تتقفل على الحاضرين.',
        yes: { lbl: 'اقفل الجلسة على الحاضرين', e:{c:0,l:2,r:-4},
               note:'قفلت الجلسة. الحكم صدر في هدوء، والتغطية اليوم اللي بعده اتكلمت عن '
                  + '«قاضٍ رفض أن يُصوَّر» أكتر ما اتكلمت عن الحكم نفسه.' },
        no:  { lbl: 'خليها مفتوحة زي ما هي', e:{c:2,l:0,r:4},
               note:'فضلت مفتوحة. الحكم اتنقل بالنص، وجزء منه اتقص من سياقه. الجزء المقصوص '
                  + 'هو اللي اتنشر.' }
      };
    }
    // اللي بيرضخ بيتطلب منه أكتر — والنبرة بتبقى أوقح
    if (P.compliance >= 4 && r < 0.55){
      return {
        frm: 'مكالمة على الخط الداخلي',
        ttl: 'نفس الصوت',
        txt: '«مش هطوّل عليك زي المرة اللي فاتت. إنت عارف إحنا بنتكلم في إيه. '
           + 'الملف ده مش محتاج مجهود، محتاج بس ما يتفتحش أوي.»',
        yes: { lbl: 'اسمع لحد الآخر وما تردّش', e:{c:-6,l:-2,r:5},
               note:'ما رديتش. السكوت اتفهم على إنه موافقة، وهو فعلاً كان موافقة.' },
        no:  { lbl: 'اقفل الخط', e:{c:5,l:3,r:-6},
               note:'قفلت. بعدها بيومين وصلك خطاب رسمي بيطلب بيان بأسباب تأجيل قضايا '
                  + 'في دائرتك من سنة فاتت. الطلب سليم شكلاً.' }
      };
    }
    // كتير النقض بيتعرض عليه «نصيحة»
    if (S.quashed >= 2 && r < 0.5){
      return {
        frm: 'مستشار أقدم — في الممر',
        ttl: 'نصيحة مش مطلوبة',
        txt: '«شوف يا ابني، أنا شفت أحكامك. مش غلط، بس متعوبة أوي. لو مشيت مع اللي الدائرة '
           + 'بتقوله، هتلاقي أحكامك بتعدي. المسألة مش شجاعة، المسألة شكل.»',
        yes: { lbl: 'خد بالنصيحة الجلسة دي', e:{c:-3,l:1,r:3},
               note:'مشيت مع الدائرة. الحكم عدّى بسهولة — ومحصلش حاجة تفتكرها.' },
        no:  { lbl: 'اشكره وامشي', e:{c:3,l:0,r:-2},
               note:'شكرته ومشيت. سمعته بيقول لواحد تاني: «ده لسه بدري عليه».' }
      };
    }
    return null;
  }

  /* ── العلاقة بالمستشارين ── */
  function rel(id){
    if (!P.rel[id]) P.rel[id] = { agree:0, dissent:0, met:0 };
    return P.rel[id];
  }

  function serialize(){ return P; }

  return { init:init, data:data, record:record, notices:notices, extraPressure:extraPressure,
           rel:rel, tier:tier, has:has, serialize:serialize, rand:rand, rng:rng, blank:blank };
})();
