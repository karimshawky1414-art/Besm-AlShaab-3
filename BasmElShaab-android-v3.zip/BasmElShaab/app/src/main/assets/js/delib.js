/* ══════════════════════════════════════════════════════════════
   delib.js — غرفة المداولة
   مش مجرد رأيين: فيه اعتراض، وسؤال عن دليل، واختلاف بين المستشارين،
   وقرارات صغيرة بيتخدها رئيس الدائرة أثناء المداولة وبتتسجل في المحضر.
   ══════════════════════════════════════════════════════════════ */
var Delib = (function(){

  var out, queue, k, panel;

  function el(html){
    var d = document.createElement('div');
    d.innerHTML = html;
    return d.firstElementChild;
  }

  function say(a, text, cls, after){
    var row = el('<div class="adv ' + (cls || '') + '">'
      + '<div class="av">' + a.i + '</div><div class="bd">'
      + '<div class="nm">' + esc(a.nm) + ' <i>· ' + esc(a.d) + '</i></div>'
      + '<div class="op" data-op></div></div></div>');
    out.appendChild(row);
    row.scrollIntoView({ block:'center', behavior:'smooth' });
    typeInto(row.querySelector('[data-op]'), text, function(){
      if (after) after(row);
    });
    return row;
  }

  function narrate(text, after){
    var row = el('<div class="delnote">' + esc(text) + '</div>');
    out.appendChild(row);
    row.scrollIntoView({ block:'center', behavior:'smooth' });
    setTimeout(after || function(){}, Settings.instant() ? 60 : 620);
  }

  /* سؤال من مستشار محتاج رد من رئيس الدائرة */
  function ask(a, text, opts, done){
    say(a, text, 'q', function(row){
      var box = el('<div class="advask"><div class="lb">رئيس الدائرة يقرّر</div></div>');
      opts.forEach(function(o, ix){
        var b = el('<button class="btn"><span class="t">' + esc(o.lbl) + '</span>'
          + (o.sub ? '<span class="s">' + esc(o.sub) + '</span>' : '') + '</button>');
        b.onclick = function(){
          box.querySelectorAll('button').forEach(function(x){ x.disabled = true; });
          b.classList.add('picked');
          penTick();
          if (o.minute){ S.minutes.push(o.minute); }
          if (o.risk){ S.risk.push(o.risk); }
          var note = el('<div class="minute">أُثبت في محضر المداولة: ' + esc(o.note) + '</div>');
          box.appendChild(note);
          setTimeout(done, Settings.instant() ? 60 : 700);
        };
        box.appendChild(b);
      });
      row.appendChild(box);
      box.scrollIntoView({ block:'center', behavior:'smooth' });
    });
  }

  /* ══ بناء مشاهد المداولة ══ */
  function build(){
    var q = [];
    var A0 = panel[0], A1 = panel[1];
    var opA = k.bench[A0.k], opB = k.bench[A1.k];
    var same = Number(opA.v) === Number(opB.v);
    var unusedProbes = (k.probes || []).filter(function(p){ return S.probes.indexOf(p.id) < 0; });
    var askedDefense = S.asked.some(function(ix){ return k.qa[ix] && k.qa[ix].w === 'الدفاع'; });
    var qCount = S.asked.length;

    // ١ — افتتاح: الدائرة بتقعد
    q.push(function(next){
      var lead = Advisors.isNewTerm()
        ? 'الدائرة اتشكّلت من أول الدورة دي. ' + panel[0].nm.replace('المستشار / ', '').replace('المستشارة / ', '')
          + ' و' + panel[1].nm.replace('المستشار / ', '').replace('المستشارة / ', '') + ' قاعدين معاك النهارده.'
        : 'الباب اتقفل. المحضر خرج، والورق قدامكم على الترابيزة.';
      narrate(lead, next);
    });

    // ٢ — نبرة + رأي المستشار الأول
    q.push(function(next){
      var t = Advisors.tone(A0);
      if (t) say(A0, t, 'tone', function(){ setTimeout(next, 320); });
      else next();
    });
    q.push(function(next){ say(A0, opA.t, '', function(row){ lean(row, opA); setTimeout(next, 420); }); });

    // ٣ — اعتراض أو سؤال عن دليل ناقص
    if (unusedProbes.length && (A1.t === 'probe' || A1.t === 'order' || A1.t === 'doubt')){
      q.push(function(next){
        var p = unusedProbes[0];
        ask(A1,
          'قبل ما نكمّل — فيه طلب ما اتقدمش في الجلسة: «' + p.label + '». '
          + 'الأوراق ناقصة الجزء ده، وأنا مش مرتاح أقول رأيي وأنا عارف إن فيه ورقة مش موجودة.',
          [
            { lbl:'أثبت النقص في المحضر وأرد عليه في الأسباب',
              sub:'بيحصّن الحكم من «القصور في التسبيب»',
              minute:'gap-addressed',
              note:'المحكمة أثبتت عدم إجراء الطلب وبيّنت سبب استغنائها عنه.' },
            { lbl:'الأوراق تكفي — نكمّل المداولة',
              sub:'أسرع، بس بيسيب ثغرة في الحكم',
              risk:'gap-ignored',
              note:'المحكمة رأت في أوراق الدعوى ما يكفي للفصل فيها.' }
          ], next);
      });
    }

    // ٤ — الدفاع ما اتناقشش
    if (!askedDefense && (A0.t === 'doubt' || A1.t === 'doubt' || A1.t === 'order' || A0.t === 'order')){
      var who = (A1.t === 'doubt' || A1.t === 'order') ? A1 : A0;
      q.push(function(next){
        ask(who,
          'الدفاع أبدى دفعه ومحدش ناقشه في الجلسة. أنا مش بقول إن الدفع صحيح — '
          + 'بقول إن الحكم لازم يرد عليه، وإلا اللي جاي بعدنا هينقضه من غير ما يقرا الوقائع.',
          [
            { lbl:'افتح للدفاع كلمة أخيرة وأثبت دفعه',
              sub:'بيمنع «الإخلال بحق الدفاع»',
              minute:'defense-heard',
              note:'أُثبت دفاع المتهم بالمحضر، والمحكمة أفردت له رداً في الأسباب.' },
            { lbl:'الدفع مردود عليه ضمناً بأدلة الثبوت',
              sub:'موقف قانوني موجود — لكنه بيتنقض كتير',
              risk:'defense-ignored',
              note:'المحكمة اعتبرت أدلة الثبوت رداً كافياً على الدفع.' }
          ], next);
      });
    }

    // ٥ — رأي المستشار التاني
    q.push(function(next){
      var t = Advisors.tone(A1);
      if (t) say(A1, t, 'tone', function(){ setTimeout(next, 300); });
      else next();
    });
    q.push(function(next){ say(A1, opB.t, '', function(row){ lean(row, opB); setTimeout(next, 420); }); });

    // ٦ — خلاف بين المستشارين نفسهم، أو اتفاق ضد اللاعب
    if (!same){
      q.push(function(next){
        say(A0, clash(A0, A1, opA, opB), 'clash', function(){ setTimeout(next, 380); });
      });
      q.push(function(next){
        say(A1, counter(A1, A0), 'clash', function(){ setTimeout(next, 380); });
      });
    } else {
      q.push(function(next){
        narrate('الاتنين على رأي واحد: ' + k.verdicts[Number(opA.v)].t
          + '. لما الدائرة تتفق من غير نقاش، المخالفة بتبقى محتاجة أسباب مكتوبة مش مجرد اقتناع.', next);
      });
    }

    // ٧ — ملاحظة على إدارة الجلسة نفسها
    q.push(function(next){
      var line = null;
      if (qCount >= 6) line = 'استجوبت كتير النهارده. الأوراق بقت مليانة، وده بيساعد في التسبيب.';
      else if (qCount <= 2) line = 'المحضر خفيف. اللي هيقرا الحكم بعدنا مش هيلاقي فيه غير اللي إحنا كتبناه.';
      else if (S.probes.length === 2) line = 'الطلبات الاتنين اتقدموا واتنفذوا. الملف بقى كامل قدر الإمكان.';
      if (!line) return next();
      narrate('همس من على يمين المنصة: «' + line + '»', next);
    });

    // ٨ — الختام
    q.push(function(next){
      narrate('المداولة تمّت. المنطوق مفتوح — والتوقيع توقيعك إنت.', next);
    });

    return q;
  }

  function lean(row, op){
    var d = el('<div class="lean">ميله: <b>' + esc(k.verdicts[Number(op.v)].t) + '</b></div>');
    row.querySelector('.bd').appendChild(d);
  }

  function clash(a, b, opA, opB){
    var mine = k.verdicts[Number(opA.v)].t, his = k.verdicts[Number(opB.v)].t;
    var pool = {
      severe: 'أنا سامع كلامك يا زميلي، بس ' + his + ' في واقعة زي دي معناها إن النص بقى اختيار. أنا متمسك بـ' + mine + '.',
      text:   'المسألة مش ذوق. النص محدد نطاق العقوبة، والباقي تقدير. ' + mine + ' جوه النطاق، و' + his + ' محتاج تسبيب أتقل بكتير.',
      mercy:  'لو حكمنا بـ' + his + ' هنبقى صح على الورق. أنا شايف إن ' + mine + ' هو اللي بيوصف الواقعة زي ما هي فعلاً.',
      doubt:  'أنا مش متأكد كفاية عشان أوصل لـ' + his + '. والشك في الجنائي مش رفاهية، ده أصل. أنا مع ' + mine + '.',
      probe:  'إحنا بنتناقش في حكم وإحنا لسه ناقصنا ورق. لو الملف اكتمل يمكن أروح لرأيك، إنما دلوقتي ' + mine + '.',
      order:  'خلينا في الشكل: أي حكم فيهم ممكن يعدّي لو اتسبب صح. اللي بيفرق إن ' + mine + ' أسهل في التسبيب من ' + his + '.'
    };
    return pool[a.t] || pool.text;
  }
  function counter(a, b){
    var pool = {
      severe: 'وأنا برضه مش هغيّر رأيي. الرأفة اللي مالهاش سند اسمها مجاملة.',
      text:   'اختلافنا مش في الوقائع، اختلافنا في تكييفها. وده اللي رئيس الدائرة هيفصل فيه.',
      mercy:  'أنا مش بطلب رحمة، بطلب إننا نبص للراجل مش للوصف بس.',
      doubt:  'اللي مش مطمّنّي إن الدليل الرئيسي واحد. لو وقع، الحكم كله بيقع معاه.',
      probe:  'رأيي إن الأصلح تأجيل واستيفاء — وأنا عارف إن ده مش هيحصل النهارده.',
      order:  'اللي يهمني إن الأسباب تحمل المنطوق. غير كده إحنا بنكتب حكم عشان يتنقض.'
    };
    return pool[a.t] || pool.text;
  }

  /* ══ التشغيل ══ */
  function run(){
    if (S.delib || S.typing) return;
    k = CASES[S.i];
    panel = Advisors.current();
    var btn = document.getElementById('dobtn');
    btn.disabled = true;
    chairSound(); setTimeout(doorThud, 500); setTimeout(paperSound, 900);
    out = document.getElementById('advout');
    out.innerHTML = '';
    document.getElementById('dnote').textContent = 'جارية…';
    S.typing = true; paintQ();

    queue = build();
    var n = 0;
    function step(){
      if (n >= queue.length) return finish();
      var fn = queue[n++];
      fn(step);
    }
    setTimeout(step, Settings.instant() ? 40 : 700);
  }

  function finish(){
    S.delib = true; S.typing = false; paintQ();
    document.getElementById('dnote').textContent = 'تمّت — القرار قرارك';
    document.getElementById('vnote').textContent = 'مفتوح';
    app.querySelectorAll('[data-v]').forEach(function(b){ b.disabled = false; });
    var pr = k.pressure || Profile.extraPressure(k);
    if (pr) setTimeout(function(){ openPressure(k, pr); }, 700);
    else setTimeout(function(){
      var v = document.querySelector('.btn.verdict');
      if (v) v.scrollIntoView({ block:'center', behavior:'smooth' });
    }, 400);
  }

  return { run:run };
})();
