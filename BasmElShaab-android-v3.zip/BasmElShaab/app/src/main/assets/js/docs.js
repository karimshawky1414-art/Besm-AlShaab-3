/* ══════════════════════════════════════════════════════════════
   docs.js — أوراق الملف
   بطاقة تحقيق شخصية مستوحاة بصرياً (مش نسخة) وعليها علامة إنها
   نموذج داخل لعبة، صور شخصية مرسومة بالكود، محاضر وتقارير بترويسة،
   لوحة أحراز، وعارض صور بالتكبير.
   كل الأسماء والأرقام والأختام خيالية بالكامل.
   ══════════════════════════════════════════════════════════════ */

/* ── رسومات توضيحية للأحراز والصور (كلها مرسومة هنا، مفيش أي أصل خارجي) ── */
var Art = (function(){
  function frame(inner, bg){
    return '<svg viewBox="0 0 200 150" class="artsvg" aria-hidden="true">'
      + '<rect width="200" height="150" fill="' + (bg || '#2A2B26') + '"/>' + inner + '</svg>';
  }
  var K = {
    cctv: function(){
      return frame(
        '<rect width="200" height="150" fill="#1B1D19"/>'
        + '<g opacity=".5"><path d="M0 20h200M0 60h200M0 100h200M0 140h200" stroke="#2E322C" stroke-width="6"/></g>'
        + '<path d="M0 118h200v32H0z" fill="#15170F"/>'
        + '<path d="M40 118l24-46h58l26 46z" fill="#3A3D33"/>'
        + '<ellipse cx="92" cy="60" rx="11" ry="13" fill="#5A5C4E"/>'
        + '<path d="M76 118c0-22 7-34 16-34s16 12 16 34z" fill="#4C4F42"/>'
        + '<rect x="120" y="86" width="26" height="20" rx="2" fill="#55584A"/>'
        + '<text x="8" y="16" fill="#9AA08C" font-size="11" font-family="monospace">CAM 03</text>'
        + '<text x="118" y="16" fill="#9AA08C" font-size="11" font-family="monospace">23:41:07</text>'
        + '<g opacity=".12"><path d="M0 0h200v150H0z" fill="url(#gr)"/></g>', '#1B1D19');
    },
    scene: function(){
      return frame(
        '<rect width="200" height="150" fill="#E7E2D4"/>'
        + '<g stroke="#8E886F" stroke-width="1.4" fill="none">'
        + '<path d="M14 14h172v122H14z"/><path d="M14 96h74M88 96v40M120 14v52M120 66h66"/></g>'
        + '<g fill="#B9AF95" opacity=".6"><rect x="24" y="24" width="34" height="20"/>'
        + '<rect x="140" y="86" width="34" height="34"/><circle cx="96" cy="60" r="9"/></g>'
        + '<g stroke="#8B1E2D" stroke-width="1.6" fill="none" stroke-dasharray="4 3">'
        + '<path d="M30 120l50-34 34 12 42-40"/></g>'
        + '<circle cx="30" cy="120" r="4" fill="#8B1E2D"/><circle cx="156" cy="58" r="4" fill="#8B1E2D"/>'
        + '<text x="16" y="146" fill="#6B6450" font-size="9">كروكي تقريبي — غير مقياسي</text>', '#E7E2D4');
    },
    phone: function(){
      return frame(
        '<rect x="66" y="18" width="68" height="116" rx="9" fill="#3C3F38" stroke="#22241F" stroke-width="2"/>'
        + '<rect x="72" y="28" width="56" height="92" rx="3" fill="#1A1C18"/>'
        + '<rect x="90" y="21" width="20" height="3" rx="1.5" fill="#22241F"/>'
        + '<circle cx="100" cy="127" r="5" fill="#22241F"/>'
        + '<g fill="#6E7264" opacity=".8"><rect x="78" y="36" width="44" height="7"/>'
        + '<rect x="78" y="49" width="34" height="7"/><rect x="78" y="62" width="40" height="7"/>'
        + '<rect x="78" y="75" width="28" height="7"/></g>'
        + '<path d="M150 40l16-8v86l-16-8z" fill="#4A4E44" opacity=".5"/>');
    },
    bag: function(){
      return frame(
        '<path d="M52 56h96l10 74H42z" fill="#4A4438" stroke="#241F17" stroke-width="2"/>'
        + '<path d="M78 56V44a22 22 0 0 1 44 0v12" fill="none" stroke="#241F17" stroke-width="5"/>'
        + '<rect x="86" y="78" width="28" height="18" rx="2" fill="#B99A5B" opacity=".8"/>'
        + '<path d="M42 96h116" stroke="#241F17" stroke-width="2" opacity=".5"/>');
    },
    car: function(){
      return frame(
        '<path d="M26 96h148l-8-26-24-22H72L44 74z" fill="#55584C" stroke="#25271F" stroke-width="2"/>'
        + '<path d="M76 52h44l18 18H62z" fill="#7E8375" opacity=".8"/>'
        + '<circle cx="62" cy="100" r="14" fill="#1E201A"/><circle cx="62" cy="100" r="6" fill="#4E5147"/>'
        + '<circle cx="140" cy="100" r="14" fill="#1E201A"/><circle cx="140" cy="100" r="6" fill="#4E5147"/>'
        + '<rect x="86" y="104" width="30" height="10" rx="2" fill="#D8D2C0"/>'
        + '<text x="88" y="112" fill="#25271F" font-size="8" font-family="monospace">ر ن ٤٢٧</text>');
    },
    knife: function(){
      return frame(
        '<path d="M40 84l68-20 10 8-66 24z" fill="#A8ACA0" stroke="#4A4E44" stroke-width="1.5"/>'
        + '<path d="M118 72l40-10 6 10-6 10-40-4z" fill="#3E3A32" stroke="#221F19" stroke-width="1.5"/>'
        + '<rect x="30" y="112" width="140" height="18" rx="2" fill="#3A3D33" opacity=".35"/>'
        + '<text x="34" y="125" fill="#C6C2B2" font-size="10">مسطرة قياس — ١٨ سم</text>');
    },
    paper: function(){
      return frame(
        '<rect x="46" y="20" width="108" height="112" fill="#E9E4D6" stroke="#B0A78D" stroke-width="1.5"/>'
        + '<g stroke="#B7AE94" stroke-width="1.6"><path d="M58 44h84M58 58h84M58 72h84M58 86h58"/></g>'
        + '<g fill="#8B1E2D" opacity=".5"><circle cx="126" cy="106" r="16" fill="none" stroke="#8B1E2D" stroke-width="2"/></g>'
        + '<path d="M58 104c8-8 14 6 22-2s12 6 20 0" fill="none" stroke="#2F3A6E" stroke-width="1.8"/>', '#DDD8C8');
    },
    cash: function(){
      return frame(
        '<g><rect x="40" y="46" width="120" height="58" rx="3" fill="#9FB08E" stroke="#5D6B4F" stroke-width="1.5"/>'
        + '<rect x="46" y="52" width="120" height="58" rx="3" fill="#AFC09D" stroke="#5D6B4F" stroke-width="1.5"/>'
        + '<circle cx="106" cy="81" r="16" fill="none" stroke="#5D6B4F" stroke-width="1.5"/>'
        + '<rect x="66" y="118" width="76" height="10" rx="2" fill="#8B1E2D" opacity=".5"/>'
        + '<text x="70" y="126" fill="#EDE8DA" font-size="8">حرز مالي</text></g>');
    },
    seal: function(){
      return frame(
        '<path d="M56 34h88v88H56z" fill="#C9C2AC" stroke="#7E7663" stroke-width="2"/>'
        + '<path d="M56 34h88v18H56z" fill="#8B1E2D" opacity=".55"/>'
        + '<g stroke="#7E7663" stroke-width="1.4"><path d="M66 66h68M66 80h68M66 94h44"/></g>'
        + '<circle cx="128" cy="104" r="15" fill="none" stroke="#8B1E2D" stroke-width="2" opacity=".6"/>'
        + '<text x="60" y="132" fill="#5E5849" font-size="9">حرز مختوم بالشمع الأحمر</text>', '#D9D3C1');
    },
    pills: function(){
      return frame(
        '<rect x="52" y="46" width="44" height="62" rx="4" fill="#D9D3C1" stroke="#7E7663" stroke-width="1.6"/>'
        + '<rect x="104" y="46" width="44" height="62" rx="4" fill="#D9D3C1" stroke="#7E7663" stroke-width="1.6"/>'
        + '<g fill="#8B1E2D" opacity=".45"><rect x="58" y="54" width="32" height="8"/><rect x="110" y="54" width="32" height="8"/></g>'
        + '<g fill="#6B6450"><circle cx="74" cy="86" r="7"/><circle cx="126" cy="86" r="7"/></g>');
    },
    key: function(){
      return frame(
        '<circle cx="66" cy="76" r="20" fill="none" stroke="#8A8270" stroke-width="7"/>'
        + '<path d="M86 76h62v10h-10v-10M120 76v14" stroke="#8A8270" stroke-width="7" fill="none"/>');
    }
  };
  function icon(kind){ return (K[kind] || K.seal)(); }
  return { icon:icon, kinds:Object.keys(K) };
})();


/* ── الصورة الشخصية: مرسومة بالكود، متغيّرة حسب الشخص ── */
var Face = (function(){
  var FEM = ['نادية','سلمى','هدى','أميرة','فاطمة','منى','سعاد','نجلاء','أمل','سميرة','ياسمين',
             'عزيزة','زينب','مريم','شيماء','دعاء','هناء','ناهد','إيمان','صفاء','وفاء','ليلى','سناء'];
  var SKIN = ['#C79A72','#B9855C','#A87049','#D2AA85','#96603D'];
  var HAIR = ['#241C14','#33261A','#1B1611','#4A3824'];
  var SCARF = ['#6B6455','#7A5B57','#4F5A5E','#6E6247','#5A5560'];
  var SHIRT = ['#4E5A62','#5C5548','#3F4A40','#65594B','#4A4550'];

  function ar2int(s){
    var m = String(s || '').replace(/[٠-٩]/g, function(d){ return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
    var y = m.match(/(19|20)\d{2}/);
    return y ? +y[0] : 1980;
  }
  function isFemale(p, who){
    var t = (p.marital || '') + ' ' + (p.job || '') + ' ' + (who || '');
    if (/متزوجة|أرملة|مطلقة|عزباء|ربة منزل|مدرّسة|مدرسة|ممرضة|طالبة|موظفة|عاملة/.test(t)) return true;
    var first = String(p.full || '').trim().split(/\s+/)[0];
    return FEM.indexOf(first) >= 0;
  }
  function seedOf(p){
    var s = String(p.nid || p.full || '').replace(/[^٠-٩0-9]/g, '');
    var n = 0;
    for (var i = 0; i < s.length; i++) n = (n * 31 + s.charCodeAt(i)) >>> 0;
    return n || 12345;
  }

  /* بيرجع SVG لصورة شخصية تقريبية — الجنس والعمر متوافقين مع بيانات الشخص */
  function svg(p, who, w, h){
    var r = Profile.rng(seedOf(p));
    var fem = isFemale(p, who);
    var age = 2025 - ar2int(p.birth);
    if (age < 16 || age > 95) age = 40;
    var pick = function(a){ return a[Math.floor(r() * a.length)]; };
    var skin = pick(SKIN), hair = pick(HAIR), scarf = pick(SCARF), shirt = pick(SHIRT);
    var grey = age >= 52 && r() < 0.85;
    var beard = !fem && (age > 26) && r() < 0.55;
    var mous = !fem && !beard && r() < 0.5;
    var glass = r() < (age > 45 ? 0.45 : 0.18);
    var W = w || 62, H = h || 76;

    var s = '<svg viewBox="0 0 62 76" width="' + W + '" height="' + H + '" class="facesvg" aria-hidden="true">';
    s += '<rect width="62" height="76" fill="#BFB9A8"/>';
    s += '<rect width="62" height="76" fill="url(#fgr)" opacity=".25"/>';
    // كتف
    s += '<path d="M4 76c0-13 11-19 27-19s27 6 27 19z" fill="' + shirt + '"/>';
    if (!fem) s += '<path d="M31 57l-7 19h14z" fill="#E3DED0" opacity=".85"/>'; // ياقة قميص
    // رقبة
    s += '<path d="M25 46h12v12h-12z" fill="' + skin + '" opacity=".92"/>';
    // وش
    s += '<ellipse cx="31" cy="34" rx="14" ry="17" fill="' + skin + '"/>';
    // شعر / طرحة
    if (fem){
      s += '<path d="M14 34c0-13 7-20 17-20s17 7 17 20v6c0 12-5 18-5 26H19c0-8-5-14-5-26z" fill="' + scarf + '"/>';
      s += '<ellipse cx="31" cy="33" rx="11.5" ry="14.5" fill="' + skin + '"/>';
      s += '<path d="M19 30c2-9 6-13 12-13s10 4 12 13z" fill="' + scarf + '" opacity=".9"/>';
    } else {
      var hc = grey ? '#9A9488' : hair;
      if (age < 60 || r() < 0.5)
        s += '<path d="M17 30c0-10 6-15 14-15s14 5 14 15c-3-5-8-7-14-7s-11 2-14 7z" fill="' + hc + '"/>';
      else
        s += '<path d="M17 32c1-6 4-9 6-10 0 4 8 5 16 3 2 1 5 3 6 7-2-9-8-14-14-14s-12 5-14 14z" fill="' + hc + '"/>';
    }
    // حواجب وعينين
    s += '<g fill="#2B2119">'
       + '<rect x="22" y="30" width="7" height="1.6" rx=".8"/><rect x="33" y="30" width="7" height="1.6" rx=".8"/>'
       + '<ellipse cx="25.5" cy="35" rx="2.2" ry="1.9" fill="#F2EEE4"/><ellipse cx="36.5" cy="35" rx="2.2" ry="1.9" fill="#F2EEE4"/>'
       + '<circle cx="25.5" cy="35" r="1.1"/><circle cx="36.5" cy="35" r="1.1"/></g>';
    // أنف وفم
    s += '<path d="M31 36v5l-2 2" fill="none" stroke="rgba(0,0,0,.28)" stroke-width="1.1" stroke-linecap="round"/>';
    s += '<path d="M27 45q4 2.5 8 0" fill="none" stroke="rgba(70,30,25,.6)" stroke-width="1.4" stroke-linecap="round"/>';
    // لحية وشنب
    if (beard) s += '<path d="M18 36c0 12 6 17 13 17s13-5 13-17c0 7-5 10-13 10s-13-3-13-10z" fill="'
                  + (grey ? '#A39C90' : hair) + '" opacity=".9"/>';
    if (mous)  s += '<path d="M26 42h10v2h-10z" rx="1" fill="' + (grey ? '#A39C90' : hair) + '"/>';
    // نظارة
    if (glass) s += '<g fill="none" stroke="#3A362C" stroke-width="1.2">'
                  + '<circle cx="25.5" cy="35" r="4.4"/><circle cx="36.5" cy="35" r="4.4"/>'
                  + '<path d="M30 35h2M17 34l4 1M45 34l-4 1"/></g>';
    // خطوط العمر
    if (age >= 50) s += '<g stroke="rgba(60,40,25,.28)" stroke-width=".9" fill="none">'
                      + '<path d="M20 30.5c1.5-1 3-1.2 4-1M38 29.5c1.5.2 3 .5 4 1.2M24 49q7 2 14 0"/></g>';
    s += '<defs><linearGradient id="fgr" x1="0" y1="0" x2="1" y2="1">'
       + '<stop offset="0" stop-color="#fff" stop-opacity=".5"/><stop offset="1" stop-color="#000" stop-opacity=".3"/>'
       + '</linearGradient></defs>';
    s += '</svg>';
    return s;
  }
  return { svg:svg, isFemale:isFemale };
})();


/* ── الحافظة: بناء الأوراق وعرضها ── */
var Docs = (function(){

  function sig(seed){
    var r = Profile.rng(seed || 7);
    var d = 'M4 18';
    for (var i = 0; i < 5; i++)
      d += ' q' + (6 + r() * 8).toFixed(1) + ' ' + (-14 + r() * 10).toFixed(1)
         + ' ' + (12 + r() * 8).toFixed(1) + ' ' + (-2 + r() * 8).toFixed(1);
    return '<svg viewBox="0 0 96 30" class="sigsvg" aria-hidden="true">'
      + '<path d="' + d + '" fill="none" stroke="#2F3A6E" stroke-width="1.6" stroke-linecap="round" opacity=".8"/></svg>';
  }

  function crest(){
    return '<svg viewBox="0 0 40 40" class="crestsvg" aria-hidden="true">'
      + '<circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" stroke-width="1.1" opacity=".55"/>'
      + '<circle cx="20" cy="20" r="14.5" fill="none" stroke="currentColor" stroke-width=".6" opacity=".35"/>'
      + '<g stroke="currentColor" stroke-width="1.3" fill="none" stroke-linecap="round" opacity=".75">'
      + '<path d="M20 10v18"/><path d="M11 15h18"/>'
      + '<path d="M11 15l-4 7h8z" fill="currentColor" fill-opacity=".18"/>'
      + '<path d="M29 15l-4 7h8z" fill="currentColor" fill-opacity=".18"/>'
      + '<path d="M15 29h10"/></g></svg>';
  }

  function serial(seed, pre){
    var n = 1000 + ((seed * 733) % 8999);
    return (pre || 'نموذج') + ' ' + arNum(n) + ' / ' + arNum(2025);
  }

  /* ══ بناء أوراق القضية ══ */
  function build(k){
    var d = [];
    d.push({ tab:'البطاقة', type:'id', p:k.person, who:k.who });
    d.push({ tab:'الفيش الجنائي', type:'form', kindLbl:'صحيفة الحالة الجنائية',
             t1:'وزارة الداخلية — مصلحة الأمن العام',
             t2:'إدارة المعلومات الجنائية — صحيفة الحالة الجنائية',
             body:k.fish, sealTxt:'إدارة<br>المعلومات<br>الجنائية' });
    d.push({ tab:'تحريات المباحث', type:'form', red:true, kindLbl:'مذكرة تحريات',
             t1:'مديرية الأمن — قسم المباحث الجنائية',
             t2:'مذكرة تحريات سرية', body:k.tahri, sealTxt:'قسم<br>المباحث' });
    (k.papers || []).forEach(function(p){
      d.push({ tab:p.k, type:'form', t1:p.k, t2:'مرفق بحافظة المستندات', body:p.t,
               sealTxt:'قلم<br>الكتّاب', kindLbl:'مرفق' });
    });
    if (k.exhibits && k.exhibits.length)
      d.push({ tab:'الأحراز', type:'exh', items:k.exhibits, num:k.num });
    if (k.images && k.images.length)
      d.push({ tab:'الصور المرفقة', type:'img', items:k.images, num:k.num });
    return d;
  }

  /* ══ العرض ══ */
  function html(d){
    if (d.type === 'id') return idHTML(d);
    if (d.type === 'exh') return exhHTML(d);
    if (d.type === 'img') return imgHTML(d);
    return formHTML(d);
  }

  function idHTML(d){
    var p = d.p;
    var seed = 0; for (var i = 0; i < String(p.nid).length; i++) seed += String(p.nid).charCodeAt(i);
    return '<div class="doc idsheet" id="docsheet">'
      + '<div class="copy">'
      + '<div class="copynote">صورة ضوئية من بطاقة تحقيق الشخصية — مرفقة بأوراق الدعوى</div>'
      + '<div class="idcard">'
      + '<div class="idband"><span class="c">' + crest() + '</span>'
      + '<span class="t1">جمهورية مصر العربية</span><span class="t2">بطاقة تحقيق الشخصية</span></div>'
      + '<div class="idwm">نموذج داخل لعبة</div>'
      + '<div class="idbody">'
      + '<div class="idphoto">' + Face.svg(p, d.who) + '<span class="pcorner"></span></div>'
      + '<div class="idf">'
      + '<span>الاسم</span>' + esc(p.full)
      + '<span>تاريخ الميلاد</span>' + esc(p.birth)
      + '<span>المهنة</span>' + esc(p.job)
      + '<span>الحالة الاجتماعية</span>' + esc(p.marital)
      + '<span>محل الإقامة</span><em>' + esc(p.addr) + '</em>'
      + '</div></div>'
      + '<div class="idnum">' + esc(p.nid) + '</div>'
      + '<div class="idfoot"><span>الرقم المسلسل ' + arNum(700000 + (seed * 91) % 99999) + '</span>'
      + '<span>صالحة حتى ' + arNum(2031) + '</span></div>'
      + '</div>'
      + '<div class="idwarn">مستند خيالي أُنشئ لأغراض اللعبة — البيانات والأرقام والصورة كلها من الخيال '
      + 'ولا تخص شخصاً حقيقياً ولا تصلح لأي استعمال خارج اللعبة.</div>'
      + '</div></div>';
  }

  function formHTML(d){
    var seed = (d.t1 || '').length + (d.body || '').length;
    return '<div class="doc" id="docsheet">'
      + '<div class="dochdr">'
      + '<div class="hcrest">' + crest() + '</div>'
      + '<div class="l1">' + d.t1 + '</div>'
      + '<div class="l2">' + d.t2 + '</div>'
      + '<div class="l3"><span>' + serial(seed, d.kindLbl || 'رقم') + '</span>'
      + '<span>الصفحة ١ من ١</span></div>'
      + '</div>'
      + '<div class="typed ruled">' + esc(d.body) + '</div>'
      + '<div class="sigrow">'
      + '<div class="sigblk">حُرِّر بتاريخه<br><span class="sl">التوقيع</span>' + sig(seed) + '</div>'
      + (d.sealTxt ? '<div class="seal ' + (d.red ? 'red' : '') + '">' + d.sealTxt + '</div>' : '')
      + '</div>'
      + '<div class="docfoot">نموذج داخل لعبة — غير صالح كمستند رسمي</div>'
      + '</div>';
  }

  function exhHTML(d){
    return '<div class="doc" id="docsheet">'
      + '<div class="dochdr"><div class="hcrest">' + crest() + '</div>'
      + '<div class="l1">النيابة العامة — قلم الأحراز</div>'
      + '<div class="l2">كشف بالأشياء المضبوطة في القضية رقم ' + esc(d.num) + '</div></div>'
      + '<div class="exhgrid">'
      + d.items.map(function(x, i){
          return '<div class="exh" data-zoom="' + i + '" data-src="exh">'
            + '<div class="exhart">' + Art.icon(x.art || 'seal') + '<span class="zoomtag">تكبير</span></div>'
            + '<div class="exhb">'
            + '<div class="exhn">حرز رقم ' + esc(x.no) + '</div>'
            + '<div class="exhd">' + esc(x.d) + '</div>'
            + '<div class="exhm"><b>الضبط</b> ' + esc(x.when || '—') + ' · ' + esc(x.where || '—') + '</div>'
            + '<div class="exhm"><b>بمعرفة</b> ' + esc(x.by || '—') + '</div>'
            + (x.note ? '<div class="exhnote">' + esc(x.note) + '</div>' : '')
            + '</div></div>';
        }).join('')
      + '</div>'
      + '<div class="docfoot">الأحراز مختومة ومودعة بخزينة المحكمة — نموذج داخل لعبة</div>'
      + '</div>';
  }

  function imgHTML(d){
    return '<div class="doc" id="docsheet">'
      + '<div class="dochdr"><div class="hcrest">' + crest() + '</div>'
      + '<div class="l1">حافظة الصور المرفقة</div>'
      + '<div class="l2">مرفقة بمحضر المعاينة — القضية رقم ' + esc(d.num) + '</div></div>'
      + '<div class="phgrid">'
      + d.items.map(function(x, i){
          return '<figure class="ph" data-zoom="' + i + '" data-src="img">'
            + '<div class="phart">' + Art.icon(x.art || 'scene') + '<span class="zoomtag">تكبير</span></div>'
            + '<figcaption>' + esc(x.k) + (x.cap ? ' — ' + esc(x.cap) : '') + '</figcaption>'
            + '</figure>';
        }).join('')
      + '</div>'
      + '<div class="docfoot">صور توضيحية مرسومة لأغراض اللعبة — لا تمثل أشخاصاً أو وقائع حقيقية</div>'
      + '</div>';
  }

  /* ══ عارض التكبير ══ */
  function zoom(src, ix){
    var k = CASES[S.i];
    var list = src === 'exh' ? (k.exhibits || []) : (k.images || []);
    var x = list[ix];
    if (!x) return;
    var v = document.getElementById('viewer');
    v.innerHTML = '<div class="vbox">'
      + '<div class="vart">' + Art.icon(x.art || (src === 'exh' ? 'seal' : 'scene')) + '</div>'
      + '<div class="vcap"><b>' + esc(src === 'exh' ? ('حرز رقم ' + x.no) : x.k) + '</b>'
      + '<span>' + esc(x.d || x.cap || '') + '</span>'
      + (x.note ? '<i>' + esc(x.note) + '</i>' : '') + '</div>'
      + '<button class="vclose">إغلاق</button></div>';
    v.classList.add('on');
    paperSound();
    v.onclick = function(){ v.classList.remove('on'); v.innerHTML = ''; };
  }

  /* بيتربط بعد كل رسم للحافظة */
  function bindZoom(){
    document.querySelectorAll('[data-zoom]').forEach(function(b){
      b.onclick = function(){ zoom(b.dataset.src, +b.dataset.zoom); };
    });
  }

  return { build:build, html:html, zoom:zoom, bindZoom:bindZoom, crest:crest };
})();
