/* ══════════════════════════════════════════════════════════════
   quash.js — الطعن بالنقض
   النقض مش مرتبط بالحكم اللي اخترته بس، ده مرتبط بإزاي أدرت القضية:
   استجواب، طلبات، رد على الدفاع، إثبات في المحضر، ورضوخ للضغط.
   ══════════════════════════════════════════════════════════════ */
var Appeals = (function(){

  /* أسباب النقض المتاحة — كل واحد بيتحسب له وزن من إدارة الجلسة */
  var REASONS = {
    qusur:   { t:'القصور في التسبيب',
               e:'الحكم قال النتيجة وما بيّنش إزاي وصل لها. الأوراق اللي بنيت عليها كانت قليلة، والأسباب ما كفتش لحمل المنطوق.' },
    haq:     { t:'الإخلال بحق الدفاع',
               e:'المحكمة ما مكّنتش الدفاع من إبداء دفاعه على الوجه الكامل، والمحضر مافيهوش ما يفيد إنها سمعته.' },
    daf3:    { t:'إغفال الرد على دفع جوهري',
               e:'الدفاع أبدى دفعاً لو صحّ لتغيّر وجه الرأي في الدعوى، والحكم عدّى عليه من غير رد.' },
    fasad:   { t:'الفساد في الاستدلال',
               e:'الحكم استخلص من الأوراق ما لا تؤدي إليه. الاستنتاج نفسه مش قائم على أصل ثابت في الملف.' },
    khata:   { t:'الخطأ في تطبيق القانون',
               e:'الواقعة زي ما هي ثابتة في الحكم بتاخد وصفاً قانونياً غير اللي المحكمة طبّقته.' },
    tanaqud: { t:'التناقض بين الأسباب والمنطوق',
               e:'الأسباب ماشية في اتجاه والمنطوق راح في اتجاه تاني، والحكم بيناقض نفسه.' },
    daleel:  { t:'الإدانة بدليل غير كافٍ',
               e:'الإدانة قامت على دليل واحد ما اتدعمش، والمحكمة ما استوفتش تحقيقاً كان ممكن يحسم الأمر.' },
    butlan:  { t:'بطلان في الإجراءات أثّر في الحكم',
               e:'فيه إجراء وقع باطلاً والحكم اتأثر بيه، ومكانش فيه في الأوراق ما يعالج البطلان ده.' }
  };

  /* ══ تقييم سلامة الحكم لحظة النطق بيه ══
     بيرجع {score, marks:[{good,txt}], reason} */
  function assess(k, v, use, ctx){
    var w = {}, marks = [];
    var add = function(key, n){ w[key] = (w[key] || 0) + n; };

    var qs      = S.asked.length;
    var probes  = S.probes.length;
    var viewed  = S.viewed ? S.viewed.length : 0;
    var askedDefense = S.asked.some(function(ix){ return k.qa[ix] && k.qa[ix].w === 'الدفاع'; });
    var minutes = S.minutes || [];
    var risks   = S.risk || [];
    var isConviction = ctx.ix > 0;

    var score = 63;

    /* ١ — سلامة الاختيار القانوني نفسه */
    score += (use.e.l || 0) * 1.6;
    if ((use.e.l || 0) <= -5){ add('khata', 26); marks.push({good:false, txt:'الوصف القانوني اللي اخترته بعيد عن ظاهر الأوراق.'}); }
    else if ((use.e.l || 0) >= 5) marks.push({good:true, txt:'المنطوق مستقيم مع النص المطبّق.'});

    /* ٢ — الاستجواب */
    if (qs >= 5){ score += 9; marks.push({good:true, txt:'استجواب مستفيض — المحضر فيه مادة تكفي للتسبيب.'}); }
    else if (qs >= 3) score += 4;
    else { score -= 9; add('qusur', 18); add('daleel', 10);
           marks.push({good:false, txt:'استجواب قليل (' + arNum(qs) + ' أسئلة) — الأسباب طلعت خفيفة.'}); }

    /* ٣ — الطلبات الإجرائية */
    if (probes >= 2){ score += 10; marks.push({good:true, txt:'الطلبات الإجرائية اتقدمت واتنفذت، والملف اكتمل.'}); }
    else if (probes === 1) score += 4;
    else { score -= 9; add('daleel', 16); add('fasad', 8);
           marks.push({good:false, txt:'ما طلبتش أي استيفاء — الحكم قام على الأوراق زي ما جت.'}); }

    /* ٤ — الرد على الدفاع */
    if (minutes.indexOf('defense-heard') >= 0){ score += 12; marks.push({good:true, txt:'دفاع المتهم اتثبت في المحضر واتردّ عليه في الأسباب.'}); }
    if (risks.indexOf('defense-ignored') >= 0){ score -= 14; add('daf3', 30); add('haq', 14);
           marks.push({good:false, txt:'الدفع الجوهري عدّى من غير رد صريح.'}); }
    if (!askedDefense && isConviction){ score -= 6; add('haq', 14);
           marks.push({good:false, txt:'المحكمة ما وجّهتش سؤال واحد للدفاع قبل الإدانة.'}); }

    /* ٥ — النقص اللي المستشار نبّه له */
    if (minutes.indexOf('gap-addressed') >= 0){ score += 8; marks.push({good:true, txt:'نقص التحقيق اتثبت واتبرّر في الأسباب.'}); }
    if (risks.indexOf('gap-ignored') >= 0){ score -= 11; add('butlan', 18); add('qusur', 14);
           marks.push({good:false, txt:'نقص في الأوراق اتنبّهت له الدائرة والحكم عدّاه.'}); }

    /* ٦ — الضغط الخارجي */
    if (S.press && S.press.e && S.press.e.l < 0){ score -= 12; add('tanaqud', 22); add('fasad', 10);
           marks.push({good:false, txt:'الحكم اتأثر بكلام من بره الملف — وده بيبان في الأسباب.'}); }
    if (S.press && S.press.e && S.press.e.l > 0){ score += 4; }

    /* ٧ — المداولة */
    if (ctx.match === 0){
      score -= 5;
      if (probes < 2 || qs < 4){ add('fasad', 16);
        marks.push({good:false, txt:'خالفت الدائرة كلها من غير ما تكوّن أوراق تسند المخالفة.'}); }
      else marks.push({good:true, txt:'خالفت الدائرة — لكن على أوراق مكتملة، وده حقك ومسنود.'});
    } else if (ctx.match === 2) score += 5;

    /* ٨ — المستندات */
    if (viewed >= 4){ score += 5; }
    else if (viewed <= 1){ score -= 6; add('qusur', 10);
           marks.push({good:false, txt:'أغلب أوراق الحافظة ما اتفتحتش.'}); }

    /* ٩ — المسار البديل (الحكم المبني على دليل مضبوط) */
    if (ctx.alt){ score += 12; marks.push({good:true, txt:'الحكم اتبنى على مستند مضبوط في الأوراق مش على تقدير مجرد.'}); }

    /* اختيار السبب الأرجح */
    var reason = null, best = 0;
    Object.keys(w).forEach(function(key){ if (w[key] > best){ best = w[key]; reason = key; } });
    if (!reason) reason = 'qusur';

    // لمسة عشوائية محدودة عشان مش كل حاجة محسوبة
    var jitter = (Profile.rand(S.i + 41) - 0.5) * 10;
    score = Math.max(2, Math.min(98, score + jitter));

    return { score: score, marks: marks, reason: reason, weight: best };
  }

  /* ══ تسجيل الطعن بعد الحكم ══ */
  function file(k, v, use, ctx){
    var a = assess(k, v, use, ctx);
    var sound = a.score >= 50;
    S.appeals.push({
      t: k.title, v: v.t,
      sound: sound,
      score: Math.round(a.score),
      why: REASONS[a.reason].t,
      whyLong: REASONS[a.reason].e,
      marks: a.marks.slice(0, 4),
      num: arNum(1200 + (S.i * 137) % 800) + ' لسنة ٢٠٢٥',
      due: S.i + 3
    });
    return a;
  }

  function marksHTML(marks){
    if (!marks || !marks.length) return '';
    return '<div class="marks">' + marks.map(function(m){
      return '<div class="mk ' + (m.good ? 'g' : 'b') + '">' + (m.good ? '✓' : '✗') + ' ' + esc(m.txt) + '</div>';
    }).join('') + '</div>';
  }

  function noticeFor(a){
    if (a.sound){
      return { kind:'appeal', k:'محكمة النقض — الطعن رقم ' + a.num, st:'أُيّد',
        body:'الطعن على حكمك في قضية <b>' + esc(a.t) + '</b> (' + esc(a.v) + ') اترفض موضوعاً. '
           + 'الدائرة قالت إن الحكم «قام على أسباب سائغة تكفي لحمله».'
           + marksHTML(a.marks)
           + '<br>السمعة +٤ · القانون +٢' };
    }
    return { kind:'appeal', bad:true, k:'محكمة النقض — الطعن رقم ' + a.num, st:'نُقض',
      body:'حكمك في قضية <b>' + esc(a.t) + '</b> (' + esc(a.v) + ') اتنقض، والدعوى اتحالت لدائرة تانية.<br>'
         + 'سبب النقض: <b>' + esc(a.why) + '</b> — ' + esc(a.whyLong || '')
         + marksHTML(a.marks)
         + '<br>السمعة −٦ · القانون −٤' };
  }

  function applyOne(a){
    if (a.sound){
      S.upheld++;
      S.r = clamp(S.r + 4); S.l = clamp(S.l + 2);
    } else {
      S.quashed++;
      S.r = clamp(S.r - 6); S.l = clamp(S.l - 4);
    }
    return noticeFor(a);
  }

  /* بيتنادى في أول كل جلسة */
  function resolve(){
    var due = S.appeals.filter(function(a){ return a.due <= S.i; });
    if (!due.length) return;
    S.appeals = S.appeals.filter(function(a){ return a.due > S.i; });
    due.forEach(function(a){ S.notices.push(applyOne(a)); });
  }

  /* ══ حصاد الدور القضائي — بيتعرض قبل شاشة النهاية ══
     أي طعن لسه معلق بيتحسم هنا عشان اللعبة ما تخلصش وفيه طعون مستنية */
  function harvest(done){
    if (!S.appeals.length) return done();
    setRoom(false);
    var pending = S.appeals.slice().sort(function(x, y){ return x.due - y.due; });
    S.appeals = [];
    var res = pending.map(applyOne);
    var up = res.filter(function(_, i){ return pending[i].sound; }).length;
    var qu = res.length - up;

    paintBench();
    app.innerHTML =
      '<div class="screen" style="padding-top:14px">'
      + '<div class="crest">⚖</div>'
      + '<h1 style="font-size:30px">حصاد الدور القضائي</h1>'
      + '<div class="sub">الطعون اللي كانت لسه منظورة قدام محكمة النقض</div>'
      + '<div class="harvline">' + arNum(res.length) + ' طعن اتحسم · '
      + arNum(up) + ' تأييد · ' + arNum(qu) + ' نقض</div>'
      + '<div style="text-align:right">' + res.map(noticeHTML).join('') + '</div>'
      + '<button class="next" id="hv">اقفل الدور القضائي</button>'
      + '<p class="note">الأحكام المنقوضة بتتحال لدائرة تانية، والمؤيدة بتدخل المجموعة. '
      + 'الأرقام دي بتتحسب في التقييم النهائي.</p>'
      + '</div>';
    document.getElementById('hv').onclick = done;
    window.scrollTo({ top:0, behavior:'instant' });
  }

  return { assess:assess, file:file, resolve:resolve, harvest:harvest, REASONS:REASONS, marksHTML:marksHTML };
})();
