/* ══════════════════════════════════════════════════════════════
   gavel.js — صوت الشاكوش
   خشب على قاعدة خشب: طقّة ناشفة + جسم قصير + ارتداد خفيف.
   من غير رنين معدني ومن غير صدى مبالغ فيه.

   لو حطيت ملف صوت بتاعك في:  assets/audio/gavel.mp3
   اللعبة هتستخدمه أوتوماتيك من غير أي تعديل في الكود.
   (يفضّل ملف قصير ٠.٣–٠.٨ ثانية، مونو، وترخيصه يسمح بالاستخدام)
   ══════════════════════════════════════════════════════════════ */
var GAVEL = (function(){

  var FILE = 'audio/gavel.mp3';
  var el = null, ready = false, checked = false;

  function probe(){
    if (checked) return;
    checked = true;
    try{
      el = new Audio(FILE);
      el.preload = 'auto';
      el.addEventListener('canplaythrough', function(){ ready = true; }, { once:true });
      el.addEventListener('error', function(){ ready = false; el = null; }, { once:true });
      el.load();
    }catch(e){ el = null; ready = false; }
  }

  function playFile(power){
    try{
      var c = el.cloneNode();
      c.volume = Math.max(0, Math.min(1, (Settings.vol()) * Math.min(1.2, power) ));
      c.play();
      return true;
    }catch(e){ return false; }
  }

  /* التوليف: خشب صلب على قاعدة خشب */
  function synth(power){
    var P = power === undefined ? 1 : power;
    var t = A.ctx.currentTime;
    var g0 = A.ctx.createGain();          // مخرج الشاكوش كله
    g0.gain.value = 1;
    g0.connect(A.master);
    // صدى بسيط جداً — القاعة بتاخد ١٥٪ بس
    if (A.verb){
      var sd = A.ctx.createGain(); sd.gain.value = 0.15;
      g0.connect(sd); sd.connect(A.verb);
    }

    /* ١ — لحظة التلامس: طقّة ناشفة قصيرة */
    var s = A.ctx.createBufferSource();
    s.buffer = noiseBuf(0.035, function(x){ return Math.pow(1 - x, 5.5); });
    var lp = A.ctx.createBiquadFilter(); lp.type = 'lowpass';
    lp.frequency.setValueAtTime(2600, t);
    lp.frequency.exponentialRampToValueAtTime(700, t + 0.05);
    var g1 = A.ctx.createGain();
    g1.gain.setValueAtTime(0.85 * P, t);
    g1.gain.exponentialRampToValueAtTime(0.0001, t + 0.055);
    s.connect(lp); lp.connect(g1); g1.connect(g0);
    s.start(t); s.stop(t + 0.06);

    /* ٢ — جسم الخشب: رنّات قصيرة مكتومة (مش نغمة موسيقية) */
    [[196, 0.55, 0.13], [301, 0.34, 0.095], [437, 0.2, 0.07]].forEach(function(v){
      var o = A.ctx.createOscillator(); o.type = 'triangle';
      o.frequency.setValueAtTime(v[0], t);
      o.frequency.exponentialRampToValueAtTime(v[0] * 0.88, t + v[2]);
      var g = A.ctx.createGain();
      g.gain.setValueAtTime(v[1] * P, t);
      g.gain.exponentialRampToValueAtTime(0.0001, t + v[2]);
      o.connect(g); g.connect(g0);
      o.start(t); o.stop(t + v[2] + 0.02);
    });

    /* ٣ — القاعدة والمنصة: دفعة واطية قصيرة، من غير boom */
    var o2 = A.ctx.createOscillator(); o2.type = 'sine';
    o2.frequency.setValueAtTime(108, t);
    o2.frequency.exponentialRampToValueAtTime(52, t + 0.16);
    var g2 = A.ctx.createGain();
    g2.gain.setValueAtTime(0.9 * P, t);
    g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
    o2.connect(g2); g2.connect(g0);
    o2.start(t); o2.stop(t + 0.24);

    /* ٤ — ارتداد الشاكوش (طقّة تانية أخف وأسرع) */
    var t2 = t + 0.062;
    var s2 = A.ctx.createBufferSource();
    s2.buffer = noiseBuf(0.02, function(x){ return Math.pow(1 - x, 6); });
    var lp2 = A.ctx.createBiquadFilter(); lp2.type = 'lowpass'; lp2.frequency.value = 1800;
    var g3 = A.ctx.createGain();
    g3.gain.setValueAtTime(0.22 * P, t2);
    g3.gain.exponentialRampToValueAtTime(0.0001, t2 + 0.05);
    s2.connect(lp2); lp2.connect(g3); g3.connect(g0);
    s2.start(t2); s2.stop(t2 + 0.06);
  }

  /* بيرجع true لو اشتغل، وساعتها الكود القديم بيقف */
  function play(power){
    probe();
    if (typeof Settings !== 'undefined' && !Settings.gavelOn()) return true; // مقفول من الإعدادات
    if (typeof audioInit === 'function') audioInit();
    if (ready && el) { Settings.vibe(24); return playFile(power); }
    if (!A.ctx || !A.on) return true;
    Settings.vibe(24);
    synth(power);
    return true;
  }

  return { play:play, hasFile:function(){ return ready; }, FILE:FILE };
})();
