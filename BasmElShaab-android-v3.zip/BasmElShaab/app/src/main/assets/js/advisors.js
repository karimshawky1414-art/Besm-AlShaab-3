/* ══════════════════════════════════════════════════════════════
   advisors.js — مستشارو الدائرة
   كل الأسماء خيالية بالكامل ولا تخص أي شخص حقيقي.
   التشكيل بيتغير كل «دورة» (٥ جلسات) مش بعد كل قضية.
   ══════════════════════════════════════════════════════════════ */
var Advisors = (function(){

  var TERM = 5; // طول الدورة بالجلسات

  /* ط = الطبع المخفي:
     severe  متشدد ومايل للعقاب
     text    نصّي — النص عنده يسبق الظرف
     mercy   بيوزن ظروف المتهم
     doubt   حذر في الإدانة، الشك عنده يفسّر لصالح المتهم
     probe   بيطلب استيفاء التحقيق قبل ما يقول رأيه
     order   شكلي — همّه سلامة الإجراءات وشكل الحكم  */
  var ROSTER = [
    { id:'gundy',  nm:'المستشار / فؤاد الجندي',    i:'ف', d:'٢٩ سنة في القضاء',            t:'severe' },
    { id:'dard',   nm:'المستشار / سامي الدرديري',  i:'س', d:'أحدث الدائرة',                 t:'mercy'  },
    { id:'shen',   nm:'المستشار / محمود الشناوي',  i:'م', d:'قادم من دائرة الجنايات',       t:'text'   },
    { id:'fouad',  nm:'المستشار / أحمد فؤاد',      i:'أ', d:'٢١ سنة، أغلبها في المستأنف',   t:'order'  },
    { id:'mansr',  nm:'المستشار / خالد منصور',     i:'خ', d:'كان وكيل نيابة قبل التعيين',   t:'severe' },
    { id:'badri',  nm:'المستشار / ياسر البدري',    i:'ي', d:'معروف بطول المداولة',          t:'probe'  },
    { id:'seyofi', nm:'المستشار / عمر السيوفي',    i:'ع', d:'أستاذ منتدب بمعهد القضاء',     t:'text'   },
    { id:'halim',  nm:'المستشارة / نادية عبد الحليم', i:'ن', d:'١٨ سنة، أولها في الأسرة',   t:'doubt'  },
    { id:'rashd',  nm:'المستشارة / سلمى راشد',     i:'ل', d:'أحدث ترقية في الدائرة',        t:'probe'  },
    { id:'zohry',  nm:'المستشار / طارق الزهري',    i:'ط', d:'مشهور بحيثياته الطويلة',       t:'order'  },
    { id:'sabri',  nm:'المستشارة / هدى صبري',      i:'هـ', d:'خبرة في قضايا الأموال العامة', t:'text'  },
    { id:'ghrib',  nm:'المستشار / مصطفى الغريب',   i:'ص', d:'قرّب على المعاش',               t:'mercy'  },
    { id:'attia',  nm:'المستشار / وائل عطية',      i:'و', d:'ندب سابق للتفتيش القضائي',      t:'order'  },
    { id:'kadi',   nm:'المستشارة / أميرة القاضي',  i:'ر', d:'حاصلة على دكتوراه في الإجراءات', t:'doubt' }
  ];

  var CUR = null, CURTERM = -1;

  function byId(id){
    for (var i = 0; i < ROSTER.length; i++) if (ROSTER[i].id === id) return ROSTER[i];
    return ROSTER[0];
  }

  /* اختيار تشكيل الدورة — ثابت داخل اللعبة الواحدة، مختلف بين لعبة وتانية */
  function pickTerm(term, seed){
    var r = Profile.rng((seed + term * 104729) >>> 0);
    var pool = ROSTER.slice();
    // أول دورة فيها الاتنين الأصليين عشان الاستمرارية مع النسخة القديمة
    if (term === 0) return [byId('gundy'), byId('dard')];
    var a = pool.splice(Math.floor(r() * pool.length), 1)[0];
    var b = pool.splice(Math.floor(r() * pool.length), 1)[0];
    // ما ينفعش الاتنين نفس الطبع — الدائرة تبقى بايخة
    var guard = 0;
    while (b.t === a.t && pool.length && guard++ < 8)
      b = pool.splice(Math.floor(r() * pool.length), 1)[0];
    return [a, b];
  }

  /* الميل الطبيعي للطبع: هل بيفضّل أخف حكم ولا أشد؟
     الأحكام في اللعبة مرتبة تقريباً من الأخف (0) للأشد (آخر واحد) */
  function leansHarsh(t){
    return t === 'severe' ? 1 : (t === 'mercy' || t === 'doubt') ? -1 : 0;
  }

  /* توزيع رأيي القضية (bench.a / bench.b) على مستشاري الدورة
     الرأي الأشد بيروح للأتشدد، والأخف للأرحم — عشان التوزيع يبقى مفهوم */
  function assign(k, panel){
    var va = Number(k.bench.a.v), vb = Number(k.bench.b.v);
    var p = panel.slice();
    var lean0 = leansHarsh(p[0].t), lean1 = leansHarsh(p[1].t);
    var aHarsher = va > vb;
    var firstGetsHarsh = (lean0 - lean1) >= 0;
    var out;
    if (va === vb) out = [Object.assign({}, p[0], {k:'a'}), Object.assign({}, p[1], {k:'b'})];
    else if (aHarsher === firstGetsHarsh)
      out = [Object.assign({}, p[0], {k:'a'}), Object.assign({}, p[1], {k:'b'})];
    else
      out = [Object.assign({}, p[0], {k:'b'}), Object.assign({}, p[1], {k:'a'})];
    return out;
  }

  /* تشكيل الجلسة الحالية — بيرجع [{id,nm,i,d,t,k}] */
  function panel(){
    var term = Math.floor(S.i / TERM);
    var k = CASES[S.i];
    var base = pickTerm(term, Profile.data().seed);
    if (term !== CURTERM){ CURTERM = term; }
    CUR = assign(k, base);
    CUR.forEach(function(a){ Profile.rel(a.id).met++; });
    return CUR;
  }
  function current(){ return CUR || panel(); }
  function isNewTerm(){ return S.i % TERM === 0 && S.i > 0; }
  function termNo(){ return Math.floor(S.i / TERM) + 1; }

  /* تسجيل نتيجة المداولة في علاقة كل مستشار */
  function recordVerdict(ix){
    if (!CUR) return;
    var k = CASES[S.i];
    CUR.forEach(function(a){
      var r = Profile.rel(a.id);
      if (Number(k.bench[a.k].v) === ix) r.agree++; else r.dissent++;
    });
  }

  /* سطر النبرة اللي بيقوله المستشار قبل رأيه — متأثر بالعلاقة والتاريخ
     مهم: النبرة بس. الرأي القانوني ما بيتغيرش بحب ولا كره. */
  function tone(a){
    var r = Profile.rel(a.id), P = Profile.data();
    var lines = [];
    if (r.met >= 3 && r.dissent >= 3 && r.dissent > r.agree * 2)
      lines.push('أنا هقول رأيي وأنا عارف إنه مش هيعدّي، بس المحضر بيتكتب.');
    if (r.met >= 3 && r.agree >= 3 && r.dissent === 0)
      lines.push('إحنا متفقين من أول الدورة، وده مش دايماً حاجة كويسة. خليني أشك في نفسي الأول.');
    if (Profile.has('كثير النقض'))
      lines.push('قبل ما أقول رأيي — ركّز في التسبيب النهارده. الدائرة عليها نظرة.');
    if (Profile.has('مشهور'))
      lines.push('الحكم ده هيتقري بره القاعة. مش سبب إننا نغيّر، سبب إننا نظبط.');
    if (Profile.has('لين') && a.t === 'order')
      lines.push('وأنا بقرا الملف حسّيت إن فيه حد اتكلم فيه قبلنا. أنا بقول اللي في الورق بس.');
    if (P.independence >= 5 && (a.t === 'mercy' || a.t === 'doubt'))
      lines.push('إنت بتخالف كتير. أنا مش بحاسبك على ده — بحاسبك على السبب.');
    if (!lines.length) return null;
    return lines[Math.floor(Profile.rand(S.i + a.id.length) * lines.length)];
  }

  return { ROSTER:ROSTER, TERM:TERM, panel:panel, current:current, recordVerdict:recordVerdict,
           tone:tone, isNewTerm:isNewTerm, termNo:termNo, byId:byId, leansHarsh:leansHarsh };
})();
